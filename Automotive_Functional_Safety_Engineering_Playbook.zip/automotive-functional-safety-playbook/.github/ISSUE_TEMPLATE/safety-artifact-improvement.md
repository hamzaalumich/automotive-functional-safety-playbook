---
name: Safety artifact improvement
description: Propose a stronger template, example, analysis pattern, or review rule
title: "[Artifact] "
labels: documentation, engineering
---

## Artifact or section

## Engineering gap

## Proposed improvement

## Safety rationale

## Assumptions or limitations
